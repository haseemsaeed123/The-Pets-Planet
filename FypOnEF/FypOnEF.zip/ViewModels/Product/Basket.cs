﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FypOnEF.ViewModels.Product
{
    public class Basket
    {
        public int PC3_Id { get; set; }

        public int OD_ProductQty { get; set; }

        public string Action { get; set; }
        
    }
}